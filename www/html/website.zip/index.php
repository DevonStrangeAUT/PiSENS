<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>HTML 5 Boilerplate</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">


</head>
<body>

<div>
    <div class="row">
        <div class="col-sm-2">
            <ul class="nav flex-column">

                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="/">Home Page</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="/temperature.php">Temperature History</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="/humidity.php">Humidity History</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#">Forecast History</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#">Pressure History</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#">Temperature History</a>
                </li>
            </ul>
        </div>
        <div class="col-sm-10">
            <h1 class="text-center">
                PiSENS: Pi Interactive Sensing Environment Notification System
            </h1>
            <div class="container text-center">
                <div class="row">
                    <div class="col">
                        <div class="readingCards card">
                            <div class="card-body">
                                <h5 class="card-title">Card Title</h5>
                                Temperature
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="readingCards card">
                            <div class="card-body">
                                <h5 class="card-title">Humidity</h5>
                                <div class="card" style="width: 18rem;">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item text-left">Local</li>
                                        <li class="list-group-item">Regional</li>
                                        <li class="list-group-item">International</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col">
                        <div class="readingCards card">
                            <div class="card-body">
                                Forecast
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="readingCards card">
                            <div class="card-body">
                                Pressure
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<script src="index.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

</body>
</html>